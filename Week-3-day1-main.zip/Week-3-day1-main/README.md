Created the about page and newsletter part for the final project 
